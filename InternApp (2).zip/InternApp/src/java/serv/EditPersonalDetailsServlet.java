package serv;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet for editing personal details.
 */
public class EditPersonalDetailsServlet extends HttpServlet {

    private static final Logger LOGGER = Logger.getLogger(EditPersonalDetailsServlet.class.getName());
    private static final String JDBC_URL = "jdbc:derby://localhost:1527/Internappdatabase";
    private static final String DB_USERNAME = "root";
    private static final String DB_PASSWORD = "root";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        String name = request.getParameter("name");
        String surname = request.getParameter("surname");
        String email = request.getParameter("email");
        String gender = request.getParameter("gender");

        try (Connection conn = DriverManager.getConnection(JDBC_URL, DB_USERNAME, DB_PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(
                     "UPDATE applicants_tbl SET name=?, surname=?, email=?, gender=? WHERE email=?")) {

            pstmt.setString(1, name);
            pstmt.setString(2, surname);
            pstmt.setString(3, email);
            pstmt.setString(4, gender);
            pstmt.setString(5, email);

            int rowsUpdated = pstmt.executeUpdate();

            if (rowsUpdated > 0) {
                LOGGER.log(Level.INFO, "User {0} updated successfully.", email);
                response.sendRedirect("edit_details_success.jsp");
            } else {
                LOGGER.log(Level.WARNING, "No user found with email {0}.", email);
                response.sendRedirect("edit_details_error.jsp");
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "SQL Error while updating user details", e);
            response.sendRedirect("edit_details_error.jsp");
        }
    }
}
